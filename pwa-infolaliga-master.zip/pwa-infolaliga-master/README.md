# pwa-infolaliga
PWA info la-liga dengan api football-data.org tugas submission 2 pwa dicoding.
